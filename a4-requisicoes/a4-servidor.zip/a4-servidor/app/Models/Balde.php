<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Balde extends Model
{
    use HasFactory;

    /*protected $table = 'baldes';
    protected $primaryKey = 'nome';
    protected $keyType = 'string';
    public $incrementing = false;*/
}
